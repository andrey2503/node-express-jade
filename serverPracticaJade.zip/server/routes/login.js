var express = require('express');
var router = express.Router();
var app=require('../app');
var mysql = require('mysql');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render(__dirname+"/../views/login.jade");
});

router.get('/loginUser',function(req,res,next){
console.log("se llamo a esto");
var user=req.query.user;
var password=req.query.password;
console.log(user);

	var condicion=verificarLogin(user,password,res);
	// console.log(condicion);
	
});


function verificarLogin(user,password,res){
var estatus="error";
var connection = mysql.createConnection({
   host: 'localhost',
   user: 'root',
   password: '',
   database: 'pruebausuarios',
   port: 3306
});
connection.connect(function(error){
   if(error){
      throw error;
   }else{

      console.log('Conexion correcta.');
   }
});

var query = connection.query('SELECT * FROM usuarios WHERE usuario = ? AND contrasena=?', [user,password], function(error, result){
      if(error){
         throw error;
      }
      else{
         var resultado = result;
         console.log("resultados "+resultado.length);
         if(resultado.length > 0){
         	console.log("existe los usuarios");
         	
           estatus="Existe el usuario";
          
            // console.log(resultado[0].nombre + ' ' + resultado[0].apellido + ' / ' + resultado[0].biografia);
         }else{
         	console.log("usuario no existe");
            estatus="usuario no existe";
           
         }
         console.log("fuera de la condicion");
         connection.end();
res.write(JSON.stringify({ existe:estatus }));
res.end();
          
      }

   }

);



}//fin de verificarLogin


module.exports = router;