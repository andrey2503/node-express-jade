var express = require('express');
var router = express.Router();
var usuarios=[];
/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  res.render(__dirname+"/../views/index1.jade");
  
});

// router.get('/registrar', function(req, res, next) {
//   // res.render('index', { title: 'Express' });
//   res.render(__dirname+"/../views/registrar.jade");
// });

// router.get('/actualizar', function(req, res, next) {
//   // res.render('index', { title: 'Express' });
//   res.render(__dirname+"/../views/actualizar.jade");
// });

// router.get('/eliminar', function(req, res, next) {
//   // res.render('index', { title: 'Express' });
//   res.render(__dirname+"/../views/eliminar.jade");
// });

// router.get('/login', function(req, res, next) {
//   // res.render('index', { title: 'Express' });
//   res.render(__dirname+"/../views/login.jade");
// });

// function anuncio(){
// 	console.log("se llamo la funcion");
// }

// function getDatos(data){
// 	console.log("se cargo los datos");
// 	console.log(data[0].nombre);
// usuarios=data;
// }

module.exports = router;
// module.exports.getDatos=getDatos;
