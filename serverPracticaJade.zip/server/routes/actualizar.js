var express = require('express');
var router = express.Router();
var app=require('../app');
var mysql=require('mysql');


/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  res.render(__dirname+"/../views/actualizar.jade");
});


router.get('/actualizarUser',function(req,res,next){
	console.log("aqui" + req.query.usuario);
	var data={usuario:req.query.usuario,contrasena:req.query.contrasena,email:req.query.email,telefono:req.query.telefono};
		console.log(data);
	// app.actualizarUsers(data);
	res.write(JSON.stringify({ existe:actualizar(data)}));
	res.end();
});

function actualizar(data){
console.log("1");
	var estatus="actualizar correcta";
var connection = mysql.createConnection({
   host: 'localhost',
   user: 'root',
   password: '',
   database: 'pruebausuarios',
   port: 3306
});
connection.connect(function(error){
   if(error){
      throw error;
   }else{

      console.log('Conexion correcta.');
   }
});
console.log("2");
var query = connection.query('UPDATE usuarios set usuario=?,contrasena=?,email=?,telefono=? WHERE usuario=?',[data.usuario,data.contrasena,data.email,data.telefono,data.usuario], function(error, result){
   if(error){
      	estatus="Error al agregar";
      throw error;

   }else{
      console.log(result);
   }
 }
);

return estatus;
}//fin de actualizar


module.exports = router;