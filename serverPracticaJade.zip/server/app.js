var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http=require("http");

var usuarios=[{nombre:"andrey",apellido:"torres",usuario:"servidor",contrasena:"admin",email:"andrey@gmail.com",
telefono:"87457020"}];

var routes = require('./routes/index');
var login=require('./routes/login');
var registrar=require('./routes/registrar');
var actualizar=require('./routes/actualizar');
var eliminar=require('./routes/eliminar');
var app = express();
var nuevasRutas = express.Router();
var mysql=require("mysql");

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/login', login);
app.use('/registrar', registrar);
app.use('/actualizar', actualizar);
app.use('/eliminar', eliminar);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


http.createServer(app).listen(8001);
// app.listen(8080);
// function getDatos(user,password){
//   for(var i=0;i< usuarios.length;i++){
//       if(usuarios[i].usuario== user && usuarios[i].contrasena==password){
//         return true;
//       }
//   }
//   return false;
//   // console.log("esto es el servidor");
// }

// function registrarUsers(data){
//   console.log('aquiii');
// usuarios.push(data);
// return true;
// }//registrar Usuarios
//  function eliminarUser(user){
//   for(var i=0;i< usuarios.length;i++){
//     if(usuarios[i].usuario==user){
//       console.log(usuarios);
//       usuarios.splice(1,i);
//       console.log(usuarios);
//       return true;
//     }//if
//   }//for
//   return false;
//  }//fin de eliminar

//  function actualizarUsers(data){
//   console.log("llego hasta aca");
//   console.log("usuario servidor"+data.usuario);
//  }//actualizar

module.exports.actualizarUsers=actualizarUsers;
module.exports.eliminarUser=eliminarUser;
module.exports.registrarUsers=registrarUsers;
module.exports.getDatos=getDatos;
module.exports = app;
