var express = require('express');
var router = express.Router();
var app=require('../app');
var mysql = require('mysql');

/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  res.render(__dirname+"/../views/registrar.jade");
});

router.get('/addUser',function(req,res,next){
var data={nombre:req.query.nombre,apellido:req.query.apellido,usuario:req.query.usuario,contrasena:req.query.contrasena,email:req.query.email,telefono:req.query.telefono};
console.log(data);

res.write(JSON.stringify({ existe:agregar(data) }));
res.end();

});

function agregar(data){
var estatus="Agregar correcto";
var connection = mysql.createConnection({
   host: 'localhost',
   user: 'root',
   password: '',
   database: 'pruebausuarios',
   port: 3306
});
connection.connect(function(error){
   if(error){
      throw error;
   }else{
      console.log('Conexion correcta.');
   }
});

var query = connection.query('INSERT INTO usuarios(nombre, apellido, usuario,contrasena,email,telefono) VALUES(?, ?, ?,?,?,?)', [data.nombre,data.apellido,data.usuario,data.contrasena,data.email,data.telefono], function(error, result){
   if(error){
      	estatus="Error al agregar";
      throw error;

   }else{
      console.log(result);
   }
 }
);


connection.end();
return estatus;
}//fin de agregar







module.exports = router;