var express = require('express');
var router = express.Router();
var app=require('../app');
var mysql = require('mysql');

/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  res.render(__dirname+"/../views/eliminar.jade");
});

router.get('/eliminarUser',function(req,res,next){
var user=req.query.user;

res.write(JSON.stringify({ existe: eliminar(user)}));
res.end();
});


function eliminar(user){

	var estatus="eliminar correcta";
var connection = mysql.createConnection({
   host: 'localhost',
   user: 'root',
   password: '',
   database: 'pruebausuarios',
   port: 3306
});
connection.connect(function(error){
   if(error){
      throw error;
   }else{

      console.log('Conexion correcta.');
   }
});

var query = connection.query('DELETE FROM usuarios WHERE usuario=?',[user], function(error, result){
   if(error){
      	estatus="Error al agregar";
      throw error;

   }else{
      console.log(result);
   }
 }
);


connection.end();
return estatus;

}//fin de eliminar

module.exports = router;