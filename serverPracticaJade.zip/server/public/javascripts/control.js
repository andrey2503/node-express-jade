function redireccion(){
	alert("se llamo");
	window.locationf="/";
}

function verificarLogin(){
	var user=document.getElementById("usuario").value;
	var password=document.getElementById("contrasena").value;
	// alert(user);
	var data={user:user,password:password}
	$.ajax({
    url : 'http://localhost:8001/login/loginUser',
    data : data,
    type : 'GET',
    dataType : 'json',
    success : function(json) {
      alert(json.existe);
    },
    error : function(xhr, status) {
        alert('Disculpe, existió un problema');
    },
 
    // código a ejecutar sin importar si la petición falló o no
    complete : function(xhr, status) {
        alert('Petición realizada');
    }
});

}//fin de verificarLogin


function registrarUsuario(){

	var user=document.getElementById("usuario").value;
	var password=document.getElementById("contrasena").value;
	var nombre=document.getElementById("nombre").value;
	var apellido=document.getElementById("apellido").value;
	var email=document.getElementById("email").value;
	var telefono=document.getElementById("telefono").value;
	var data={nombre:nombre,apellido:apellido,usuario:user,contrasena:password,email:email,telefono:telefono};
	$.ajax({
    // la URL para la petición
    url : 'http://localhost:8001/registrar/addUser',
    data : data,
 
    type : 'GET',
    dataType : 'json',
    success : function(json) {
      alert(json.existe);
    },
    error : function(xhr, status) {
        alert('Disculpe, existió un problema');
    },
 
    // código a ejecutar sin importar si la petición falló o no
    complete : function(xhr, status) {
        alert('Petición realizada');
    }
});
}//fin de agregarUsuario


function eliminarUsuario(){

	var user=document.getElementById("usuario").value;
	
	var data={user:user};
	$.ajax({
    // la URL para la petición
    url : 'http://localhost:8001/eliminar/eliminarUser',
    data : data,
    type : 'GET',
    dataType : 'json',
    success : function(json) {
      alert(json.existe);
    },
    error : function(xhr, status) {
        alert('Disculpe, existió un problema');
    },
 
    // código a ejecutar sin importar si la petición falló o no
    complete : function(xhr, status) {
        alert('Petición realizada');
    }
});
}//fin de agregarUsuario

function actualizarUsuario(){

	var user=document.getElementById("usuario").value;
	var password=document.getElementById("contrasena").value;
	var email=document.getElementById("email").value;
	var telefono=document.getElementById("telefono").value;
	var data={usuario:user,contrasena:password,email:email,telefono:telefono};
	$.ajax({
    // la URL para la petición
    url : 'http://localhost:8001/actualizar/actualizarUser',
    data : data,
 
    type : 'GET',
    dataType : 'json',
    success : function(json) {
      alert(json.existe);
    },
    error : function(xhr, status) {
        alert('Disculpe, existió un problema');
    },
 
    // código a ejecutar sin importar si la petición falló o no
    complete : function(xhr, status) {
        alert('Petición realizada');
    }
});

}//fin de actualizar